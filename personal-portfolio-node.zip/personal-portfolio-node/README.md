# Personal Portfolio (HTML/CSS/JS + Node/Express)

## Quick Start
1. Install dependencies: `npm install`
2. Copy `.env.example` to `.env` and (optionally) fill SMTP settings.
3. Run locally: `npm run dev`
4. Open http://localhost:3000

Contact form submits to `/api/contact` and stores messages in `data/messages.json`. If SMTP values are set, it will also send an email.
