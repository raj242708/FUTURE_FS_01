const $ = (sel) => document.querySelector(sel);

// Year
$("#year").textContent = new Date().getFullYear();

// Theme toggle
const root = document.documentElement;
const saved = localStorage.getItem("theme");
if (saved === "light") document.body.classList.add("light");
$("#theme-toggle").addEventListener("click", () => {
  document.body.classList.toggle("light");
  localStorage.setItem("theme", document.body.classList.contains("light") ? "light" : "dark");
});

// Smooth scroll
document.querySelectorAll('a[href^="#"]').forEach(a => {
  a.addEventListener("click", (e) => {
    const id = a.getAttribute("href");
    if (id.length > 1) {
      e.preventDefault();
      document.querySelector(id).scrollIntoView({ behavior: "smooth", block: "start" });
    }
  });
});

// Contact form
const form = $("#contact-form");
const statusEl = $("#form-status");
form?.addEventListener("submit", async (e) => {
  e.preventDefault();
  statusEl.textContent = "Sending...";
  const body = Object.fromEntries(new FormData(form).entries());
  try {
    const res = await fetch("/api/contact", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body)
    });
    const data = await res.json();
    if (data.ok) {
      statusEl.textContent = "Thanks! I'll get back to you soon.";
      form.reset();
    } else {
      statusEl.textContent = data.error || "Something went wrong.";
    }
  } catch (err) {
    statusEl.textContent = "Network error. Please try again.";
  }
});
