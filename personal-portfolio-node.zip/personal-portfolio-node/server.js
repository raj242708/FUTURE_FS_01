import express from "express";
import path from "path";
import fs from "fs";
import morgan from "morgan";
import helmet from "helmet";
import dotenv from "dotenv";
import cors from "cors";

dotenv.config();
const app = express();
const PORT = process.env.PORT || 3000;
const __dirname = path.resolve();

// Middleware
app.use(helmet({
  contentSecurityPolicy: false
}));
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(morgan("dev"));

// Static files
app.use(express.static(path.join(__dirname, "public")));

// API route: contact form
app.post("/api/contact", async (req, res) => {
  try {
    const { name, email, message } = req.body;
    if (!name || !email || !message) {
      return res.status(400).json({ ok: false, error: "All fields are required." });
    }

    // Save message to data/messages.json
    const dataDir = path.join(__dirname, "data");
    const filePath = path.join(dataDir, "messages.json");
    await fs.promises.mkdir(dataDir, { recursive: true });
    let existing = [];
    try {
      existing = JSON.parse(await fs.promises.readFile(filePath, "utf-8"));
    } catch (_) {}
    existing.push({ name, email, message, createdAt: new Date().toISOString() });
    await fs.promises.writeFile(filePath, JSON.stringify(existing, null, 2));

    // Optional email via Nodemailer (requires .env configuration)
    if (process.env.SMTP_HOST && process.env.SMTP_USER && process.env.SMTP_PASS && process.env.CONTACT_TO) {
      const nodemailer = (await import("nodemailer")).default;
      const transporter = nodemailer.createTransport({
        host: process.env.SMTP_HOST,
        port: Number(process.env.SMTP_PORT) || 587,
        secure: Boolean(process.env.SMTP_SECURE) || false,
        auth: {
          user: process.env.SMTP_USER,
          pass: process.env.SMTP_PASS
        }
      });
      await transporter.sendMail({
        from: `"Portfolio Contact" <${process.env.SMTP_USER}>`,
        to: process.env.CONTACT_TO,
        subject: "New portfolio message",
        text: `From: ${name} <${email}>\n\n${message}`
      });
    }

    res.json({ ok: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ ok: false, error: "Server error." });
  }
});

// Fallback to index.html
app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
